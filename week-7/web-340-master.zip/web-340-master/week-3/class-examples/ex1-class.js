/*
============================================
; Title:  ex1-class.js
; Author: Professor Krasso
; Date:   1 August 2022
; Description: Class Example
;===========================================
*/

class Person {

}

class Person {
    constructor() {

    }
}

class Person {
    constructor (firstName, lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
}

class Person {
    constructor (fname, lname) {
        this.firstName = fname;
        this.lastName = lname;
    }
}
