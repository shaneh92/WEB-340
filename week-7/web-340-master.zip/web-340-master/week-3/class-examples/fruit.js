/*
============================================
; Title:  fruit.js
; Author: Professor Krasso
; Date:   1 August 2022
; Description: Class Example
;===========================================
*/

class Fruit {
    constructor(name) {
        this.name = name;
    }
}

let fruit = new Fruit("Apple");
console.log(fruit.name);
