/*
============================================
; Title:  ex2-modules.js
; Author: Professor Krasso
; Date:   1 August 2022
; Description: Node Modules Example
;===========================================
*/

module.exports.getName = function(name) {
    return "My name is " + name;
}
