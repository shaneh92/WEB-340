Learn About Me
==============

This example is very similar to the one in the book. The only difference is that the `mongoose` dependency has been updated to version 4 to fix some errors.
