/*
============================================
; Title:  ex1-arr.js
; Author: Professor Krasso
; Date:   1 August 2022
; Description: String Array Example
;===========================================
*/

const fruits = ['Apple', 'Orange', 'Banana', 'Grapes', 'Strawberries'];

for (let fruit of fruits) {
    console.log(fruit);
}
