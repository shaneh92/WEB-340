/*
============================================
; Title:  ex3-modules.js
; Author: Professor Krasso
; Date:   1 August 2022
; Description: Node Modules Example
;===========================================
*/

function add(num1, num2) {
    return num1 + num2;
}

module.exports = { add }
