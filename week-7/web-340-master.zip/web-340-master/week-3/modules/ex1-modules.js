/*
============================================
; Title:  ex1-modules.js
; Author: Professor Krasso
; Date:   1 August 2022
; Description: Node Modules Example
;===========================================
*/

function getName() {
    return "My name is Professor Krasso";
}

module.exports = getName;
