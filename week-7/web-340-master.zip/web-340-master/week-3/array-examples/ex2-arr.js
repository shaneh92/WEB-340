/*
============================================
; Title:  ex2-arr.js
; Author: Professor Krasso
; Date:   1 August 2022
; Description: Number Array Example
;===========================================
*/

const numbers = [10, 20, 30, 40, 50];

for (let number of numbers) {
    console.log(number);
}
