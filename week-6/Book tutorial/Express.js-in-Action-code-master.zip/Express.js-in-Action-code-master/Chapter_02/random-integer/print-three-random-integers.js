var randomInt = require("./random-integer");
console.log(randomInt());
console.log(randomInt());
console.log(randomInt());
